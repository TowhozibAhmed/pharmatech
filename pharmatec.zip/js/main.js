(function ($) {
    "use strict";

    jQuery(document).ready(function ($) {




        $('.filter-button').click(function () {

            $('.filter-button').removeClass('active');
            $(this).addClass('active');

        });




    });



}(jQuery));